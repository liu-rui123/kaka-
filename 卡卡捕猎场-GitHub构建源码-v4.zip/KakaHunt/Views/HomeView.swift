import CoreTransferable
import PhotosUI
import SwiftUI
import UniformTypeIdentifiers
import UIKit

struct HomeView: View {
    @EnvironmentObject private var store: SettingsStore
    @State private var isPresentingGame = false
    @State private var showGuidedAccessTip = false
    @State private var backgroundPickerItem: PhotosPickerItem?
    @State private var movementVideoPickerItem: PhotosPickerItem?
    @State private var isImportingAudioFile = false
    @State private var isProcessingMovementSound = false
    @State private var importError: String?

    var body: some View {
        NavigationStack {
            Form {
                brandHeader

                Section {
                    ForEach(store.settings.profiles) { profile in
                        NavigationLink {
                            TargetEditorView(kind: profile.kind)
                        } label: {
                            HStack(spacing: 12) {
                                Text(profile.kind.emoji)
                                    .font(.system(size: 34))
                                    .frame(width: 44)

                                VStack(alignment: .leading, spacing: 3) {
                                    Text(profile.kind.displayName)
                                        .font(.headline)
                                    Text(profileSummary(profile))
                                        .font(.caption)
                                        .foregroundStyle(.secondary)
                                }

                                Spacer()

                                Image(systemName: profile.isEnabled ? "checkmark.circle.fill" : "circle")
                                    .foregroundStyle(profile.isEnabled ? Color.green : Color.secondary)
                            }
                        }
                    }
                } header: {
                    Text("移动目标")
                } footer: {
                    Text("点进每种物体，可单独设置大小、速度和自定义脸图。至少保留一种目标。")
                }

                Section {
                    Stepper(value: targetCountBinding, in: 1...8) {
                        HStack {
                            Text("同时出现")
                            Spacer()
                            Text("\(store.settings.activeTargetCount) 个")
                                .foregroundStyle(.secondary)
                        }
                    }

                } header: {
                    Text("游戏设置")
                }

                backgroundSection

                soundSection

                Section {
                    Button {
                        isPresentingGame = true
                    } label: {
                        Label("开始捕猎", systemImage: "play.fill")
                            .font(.title3.bold())
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 8)
                    }
                    .buttonStyle(.borderedProminent)
                    .tint(.orange)
                    .listRowBackground(Color.clear)
                } footer: {
                    Text("进入游戏后，普通触碰不会暂停。右上角长按 3 秒可返回设置。")
                }
            }
            .navigationTitle("卡卡捕猎场")
            .fullScreenCover(isPresented: $isPresentingGame) {
                GameView(settings: store.settings) {
                    isPresentingGame = false
                }
            }
            .onAppear {
                if !store.settings.hasShownGuidedAccessTip {
                    showGuidedAccessTip = true
                }
            }
            .alert("建议开启引导式访问", isPresented: $showGuidedAccessTip) {
                Button("知道了") {
                    store.markGuidedAccessTipShown()
                }
            } message: {
                Text("游戏不会因猫爪触碰暂停。若还想防止猫咪退出应用或拉出系统界面，可在系统设置中开启“引导式访问”，进入游戏后连按三次侧边键启用。")
            }
            .alert("导入失败", isPresented: Binding(
                get: { importError != nil },
                set: { if !$0 { importError = nil } }
            )) {
                Button("好", role: .cancel) {}
            } message: {
                Text(importError ?? "未知错误")
            }
            .onChange(of: backgroundPickerItem) { item in
                loadBackground(from: item)
            }
            .onChange(of: movementVideoPickerItem) { item in
                loadMovementSound(from: item)
            }
            .fileImporter(
                isPresented: $isImportingAudioFile,
                allowedContentTypes: [.audio]
            ) { result in
                importAudioFile(result)
            }
        }
    }

    private var backgroundSection: some View {
        Section {
            Picker("游戏背景", selection: backgroundBinding) {
                ForEach(availableBackgroundStyles) { style in
                    Label(style.displayName, systemImage: style.symbolName)
                        .tag(style)
                }
            }

            PhotosPicker(selection: $backgroundPickerItem, matching: .images) {
                Label("从相册选择自定义背景", systemImage: "photo.on.rectangle")
            }

            if let image = BackgroundImageStore.image(filename: store.settings.customBackgroundFilename) {
                Image(uiImage: image)
                    .resizable()
                    .scaledToFill()
                    .frame(height: 120)
                    .frame(maxWidth: .infinity)
                    .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))

                Button(role: .destructive) {
                    BackgroundImageStore.remove(filename: store.settings.customBackgroundFilename)
                    store.update {
                        $0.customBackgroundFilename = nil
                        if $0.backgroundStyle == .custom {
                            $0.backgroundStyle = .midnight
                        }
                    }
                } label: {
                    Label("删除自定义背景", systemImage: "trash")
                }
            }
        } header: {
            Text("背景")
        } footer: {
            Text("自定义背景照片会压缩后保存在本机，游戏时自动铺满屏幕。")
        }
    }

    private var soundSection: some View {
        Section {
            Toggle("移动吸引声", isOn: movementSoundBinding)

            if store.settings.movementSoundEnabled {
                VStack(alignment: .leading, spacing: 8) {
                    HStack {
                        Text("移动声音量")
                        Spacer()
                        Text("\(Int((store.settings.movementSoundVolume * 100).rounded()))%")
                            .foregroundStyle(.secondary)
                    }
                    Slider(value: movementSoundVolumeBinding, in: 0...1)
                }

                PhotosPicker(selection: $movementVideoPickerItem, matching: .videos) {
                    Label("从相册视频提取声音", systemImage: "video.badge.waveform")
                }
                .disabled(isProcessingMovementSound)

                Button {
                    isImportingAudioFile = true
                } label: {
                    Label("从“文件”导入音频", systemImage: "waveform.badge.plus")
                }
                .disabled(isProcessingMovementSound)

                if isProcessingMovementSound {
                    HStack {
                        ProgressView()
                        Text("正在提取并保存音频…")
                            .foregroundStyle(.secondary)
                    }
                } else if store.settings.customMovementSoundFilename != nil {
                    Label("当前：自定义移动声", systemImage: "checkmark.circle.fill")
                        .foregroundStyle(.green)

                    Button(role: .destructive) {
                        MovementSoundStore.remove(filename: store.settings.customMovementSoundFilename)
                        store.update { $0.customMovementSoundFilename = nil }
                    } label: {
                        Label("恢复默认老鼠“窸窸窣窣”声", systemImage: "arrow.counterclockwise")
                    }
                } else {
                    Label("当前：默认老鼠“窸窸窣窣”声", systemImage: "speaker.wave.2.fill")
                        .foregroundStyle(.secondary)
                }
            }

            Toggle("命中打击声", isOn: hitSoundBinding)
        } header: {
            Text("音效")
        } footer: {
            Text("视频只会提取音轨，不会在游戏中播放画面。自定义声音较长时会播完后再次触发，不会重叠。")
        }
    }

    private var brandHeader: some View {
        Section {
            HStack(spacing: 16) {
                Image("BrandLogo")
                    .resizable()
                    .scaledToFill()
                    .frame(width: 78, height: 78)
                    .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
                    .accessibilityHidden(true)

                VStack(alignment: .leading, spacing: 5) {
                    Text("给卡卡一场不会暂停的追逐游戏")
                        .font(.headline)
                    Text("选择目标，然后把设备平放或固定好。")
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                }
            }
            .padding(.vertical, 6)
        }
    }

    private var targetCountBinding: Binding<Int> {
        Binding(
            get: { store.settings.activeTargetCount },
            set: { value in store.update { $0.activeTargetCount = value } }
        )
    }

    private var movementSoundBinding: Binding<Bool> {
        Binding(
            get: { store.settings.movementSoundEnabled },
            set: { value in store.update { $0.movementSoundEnabled = value } }
        )
    }

    private var hitSoundBinding: Binding<Bool> {
        Binding(
            get: { store.settings.hitSoundEnabled },
            set: { value in store.update { $0.hitSoundEnabled = value } }
        )
    }

    private var movementSoundVolumeBinding: Binding<Double> {
        Binding(
            get: { store.settings.movementSoundVolume },
            set: { value in store.update { $0.movementSoundVolume = value } }
        )
    }

    private var backgroundBinding: Binding<GameBackgroundStyle> {
        Binding(
            get: { store.settings.backgroundStyle },
            set: { value in store.update { $0.backgroundStyle = value } }
        )
    }

    private var availableBackgroundStyles: [GameBackgroundStyle] {
        GameBackgroundStyle.allCases.filter {
            $0 != .custom || store.settings.customBackgroundFilename != nil
        }
    }

    private func profileSummary(_ profile: TargetProfile) -> String {
        let sizePercent = Int((profile.normalizedSize * 100).rounded())
        let faceText = profile.faceImageFilename == nil ? "默认脸" : "自定义脸"
        return "\(profile.isEnabled ? "已启用" : "未启用") · 大小 \(sizePercent)% · \(speedLabel(profile.normalizedSpeed)) · \(faceText)"
    }

    private func speedLabel(_ value: Double) -> String {
        switch value {
        case ..<0.65: return "慢速"
        case ..<1.40: return "适中"
        default: return "快速"
        }
    }

    private func loadBackground(from item: PhotosPickerItem?) {
        guard let item else { return }
        Task { @MainActor in
            defer { backgroundPickerItem = nil }
            do {
                guard let data = try await item.loadTransferable(type: Data.self),
                      let image = UIImage(data: data) else {
                    throw BackgroundImageStoreError.encodingFailed
                }
                let filename = try BackgroundImageStore.save(image)
                store.update {
                    $0.customBackgroundFilename = filename
                    $0.backgroundStyle = .custom
                }
            } catch {
                importError = "无法读取或保存这张背景照片，请换一张再试。"
            }
        }
    }

    private func loadMovementSound(from item: PhotosPickerItem?) {
        guard let item else { return }
        isProcessingMovementSound = true
        Task { @MainActor in
            defer {
                movementVideoPickerItem = nil
                isProcessingMovementSound = false
            }
            do {
                guard let video = try await item.loadTransferable(type: ImportedVideo.self) else {
                    throw MovementSoundStoreError.exportUnavailable
                }
                defer { try? FileManager.default.removeItem(at: video.url) }
                let filename = try await MovementSoundStore.saveAudio(from: video.url)
                store.update { $0.customMovementSoundFilename = filename }
            } catch {
                importError = "无法从这个视频提取音频，请换一个视频再试。"
            }
        }
    }

    private func importAudioFile(_ result: Result<URL, Error>) {
        do {
            let sourceURL = try result.get()
            let stagedURL = try stageImportedFile(sourceURL)
            isProcessingMovementSound = true
            Task { @MainActor in
                defer {
                    try? FileManager.default.removeItem(at: stagedURL)
                    isProcessingMovementSound = false
                }
                do {
                    let filename = try await MovementSoundStore.saveAudio(from: stagedURL)
                    store.update { $0.customMovementSoundFilename = filename }
                } catch {
                    importError = "无法转换这个音频文件，请尝试 MP3、M4A 或 WAV 格式。"
                }
            }
        } catch {
            importError = "无法读取这个音频文件。"
        }
    }

    private func stageImportedFile(_ sourceURL: URL) throws -> URL {
        let hasAccess = sourceURL.startAccessingSecurityScopedResource()
        defer {
            if hasAccess {
                sourceURL.stopAccessingSecurityScopedResource()
            }
        }

        let fileExtension = sourceURL.pathExtension.isEmpty ? "m4a" : sourceURL.pathExtension
        let destination = FileManager.default.temporaryDirectory
            .appendingPathComponent("movement-audio-\(UUID().uuidString)")
            .appendingPathExtension(fileExtension)
        try FileManager.default.copyItem(at: sourceURL, to: destination)
        return destination
    }
}

private struct ImportedVideo: Transferable {
    let url: URL

    static var transferRepresentation: some TransferRepresentation {
        FileRepresentation(contentType: .movie) { video in
            SentTransferredFile(video.url)
        } importing: { received in
            let fileExtension = received.file.pathExtension.isEmpty ? "mov" : received.file.pathExtension
            let destination = FileManager.default.temporaryDirectory
                .appendingPathComponent("movement-video-\(UUID().uuidString)")
                .appendingPathExtension(fileExtension)
            try FileManager.default.copyItem(at: received.file, to: destination)
            return ImportedVideo(url: destination)
        }
    }
}
