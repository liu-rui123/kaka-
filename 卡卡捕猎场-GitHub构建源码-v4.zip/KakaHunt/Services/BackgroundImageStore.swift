import UIKit

enum BackgroundImageStoreError: Error {
    case encodingFailed
}

enum BackgroundImageStore {
    private static let folderName = "GameBackground"
    private static let filename = "custom-background.jpg"

    static func save(_ image: UIImage) throws -> String {
        let preparedImage = resized(image, maximumDimension: 2_732)
        guard let data = preparedImage.jpegData(compressionQuality: 0.86) else {
            throw BackgroundImageStoreError.encodingFailed
        }

        let directory = try directoryURL()
        try data.write(to: directory.appendingPathComponent(filename), options: .atomic)
        return filename
    }

    static func image(filename: String?) -> UIImage? {
        guard let filename,
              let directory = try? directoryURL(createIfNeeded: false) else { return nil }
        let safeFilename = URL(fileURLWithPath: filename).lastPathComponent
        return UIImage(contentsOfFile: directory.appendingPathComponent(safeFilename).path)
    }

    static func remove(filename: String?) {
        guard let filename,
              let directory = try? directoryURL(createIfNeeded: false) else { return }
        let safeFilename = URL(fileURLWithPath: filename).lastPathComponent
        try? FileManager.default.removeItem(at: directory.appendingPathComponent(safeFilename))
    }

    private static func resized(_ image: UIImage, maximumDimension: CGFloat) -> UIImage {
        let longestSide = max(image.size.width, image.size.height)
        guard longestSide > maximumDimension, longestSide > 0 else { return image }

        let ratio = maximumDimension / longestSide
        let targetSize = CGSize(
            width: max(1, (image.size.width * ratio).rounded()),
            height: max(1, (image.size.height * ratio).rounded())
        )
        let format = UIGraphicsImageRendererFormat.default()
        format.scale = 1
        format.opaque = true
        return UIGraphicsImageRenderer(size: targetSize, format: format).image { _ in
            image.draw(in: CGRect(origin: .zero, size: targetSize))
        }
    }

    private static func directoryURL(createIfNeeded: Bool = true) throws -> URL {
        let root = try FileManager.default.url(
            for: .applicationSupportDirectory,
            in: .userDomainMask,
            appropriateFor: nil,
            create: createIfNeeded
        )
        let directory = root.appendingPathComponent(folderName, isDirectory: true)
        if createIfNeeded, !FileManager.default.fileExists(atPath: directory.path) {
            try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
        }
        return directory
    }
}
