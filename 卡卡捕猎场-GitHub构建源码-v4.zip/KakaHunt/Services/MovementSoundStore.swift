import AVFoundation

enum MovementSoundStoreError: Error {
    case exportUnavailable
    case exportFailed
}

enum MovementSoundStore {
    private static let folderName = "MovementSounds"
    private static let filename = "custom-movement.m4a"

    static func saveAudio(from mediaURL: URL) async throws -> String {
        let asset = AVURLAsset(url: mediaURL)
        guard let exporter = AVAssetExportSession(
            asset: asset,
            presetName: AVAssetExportPresetAppleM4A
        ) else {
            throw MovementSoundStoreError.exportUnavailable
        }

        let directory = try directoryURL()
        let outputURL = directory
            .appendingPathComponent("movement-export-\(UUID().uuidString)")
            .appendingPathExtension("m4a")

        exporter.outputURL = outputURL
        exporter.outputFileType = .m4a
        exporter.shouldOptimizeForNetworkUse = true

        await withCheckedContinuation { (continuation: CheckedContinuation<Void, Never>) in
            exporter.exportAsynchronously {
                continuation.resume()
            }
        }

        guard exporter.status == .completed else {
            try? FileManager.default.removeItem(at: outputURL)
            throw exporter.error ?? MovementSoundStoreError.exportFailed
        }

        let finalURL = directory.appendingPathComponent(filename)
        if FileManager.default.fileExists(atPath: finalURL.path) {
            try FileManager.default.removeItem(at: finalURL)
        }
        try FileManager.default.moveItem(at: outputURL, to: finalURL)
        return filename
    }

    static func audioURL(filename: String?) -> URL? {
        guard let filename,
              let directory = try? directoryURL(createIfNeeded: false) else { return nil }
        let safeFilename = URL(fileURLWithPath: filename).lastPathComponent
        let url = directory.appendingPathComponent(safeFilename)
        return FileManager.default.fileExists(atPath: url.path) ? url : nil
    }

    static func remove(filename: String?) {
        guard let url = audioURL(filename: filename) else { return }
        try? FileManager.default.removeItem(at: url)
    }

    private static func directoryURL(createIfNeeded: Bool = true) throws -> URL {
        let root = try FileManager.default.url(
            for: .applicationSupportDirectory,
            in: .userDomainMask,
            appropriateFor: nil,
            create: createIfNeeded
        )
        let directory = root.appendingPathComponent(folderName, isDirectory: true)
        if createIfNeeded, !FileManager.default.fileExists(atPath: directory.path) {
            try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
        }
        return directory
    }
}
