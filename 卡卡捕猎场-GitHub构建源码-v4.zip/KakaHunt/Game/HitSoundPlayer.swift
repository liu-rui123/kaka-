import AVFoundation

final class GameSoundPlayer {
    private let engine = AVAudioEngine()
    private let hitPlayer = AVAudioPlayerNode()
    private let attractPlayer = AVAudioPlayerNode()
    private let format = AVAudioFormat(standardFormatWithSampleRate: 44_100, channels: 1)!
    private var customMovementPlayer: AVAudioPlayer?
    private var isReady = false

    init() {
        engine.attach(hitPlayer)
        engine.attach(attractPlayer)
        engine.connect(hitPlayer, to: engine.mainMixerNode, format: format)
        engine.connect(attractPlayer, to: engine.mainMixerNode, format: format)
        engine.mainMixerNode.outputVolume = 0.35
    }

    func configureMovementSound(volume: Double, customSoundURL: URL?) {
        let normalizedVolume = min(max(volume, 0), 1)
        attractPlayer.volume = Float(normalizedVolume)

        guard let customSoundURL,
              let player = try? AVAudioPlayer(contentsOf: customSoundURL) else {
            customMovementPlayer = nil
            return
        }
        player.volume = Float(normalizedVolume * 0.35)
        player.numberOfLoops = 0
        player.prepareToPlay()
        customMovementPlayer = player
    }

    func playHit() {
        prepareIfNeeded()
        guard isReady else { return }

        scheduleTone(
            on: hitPlayer,
            duration: 0.10,
            startFrequency: Double.random(in: 760...940),
            endFrequency: Double.random(in: 520...650),
            amplitude: 0.42,
            decay: 30
        )
    }

    func playMovementSound() {
        prepareIfNeeded()
        guard isReady else { return }

        if let customMovementPlayer {
            guard !customMovementPlayer.isPlaying else { return }
            customMovementPlayer.currentTime = 0
            customMovementPlayer.play()
            return
        }

        let duration = 0.46
        let frameCount = AVAudioFrameCount(format.sampleRate * duration)
        guard let buffer = AVAudioPCMBuffer(pcmFormat: format, frameCapacity: frameCount),
              let samples = buffer.floatChannelData?[0] else { return }

        buffer.frameLength = frameCount
        var smoothedNoise = 0.0

        for frame in 0..<Int(frameCount) {
            let progress = Double(frame) / Double(max(1, Int(frameCount) - 1))
            let rawNoise = Double.random(in: -1...1)
            smoothedNoise = smoothedNoise * 0.76 + rawNoise * 0.24

            let pulse = pow(max(0, sin(progress * .pi * 7)), 2)
            let overallEnvelope = sin(progress * .pi)
            samples[frame] = Float(smoothedNoise * pulse * overallEnvelope * 0.34)
        }

        attractPlayer.scheduleBuffer(buffer, completionHandler: nil)
        if !attractPlayer.isPlaying {
            attractPlayer.play()
        }
    }

    func stop() {
        hitPlayer.stop()
        stopMovementSound()
        engine.stop()
        isReady = false
    }

    func stopMovementSound() {
        attractPlayer.stop()
        customMovementPlayer?.stop()
    }

    private func prepareIfNeeded() {
        guard !isReady else { return }

        let session = AVAudioSession.sharedInstance()
        try? session.setCategory(.ambient, mode: .default, options: [.mixWithOthers])
        try? session.setActive(true)

        engine.prepare()
        do {
            try engine.start()
            isReady = true
        } catch {
            isReady = false
        }
    }

    private func scheduleTone(
        on player: AVAudioPlayerNode,
        duration: Double,
        startFrequency: Double,
        endFrequency: Double,
        amplitude: Double,
        decay: Double
    ) {
        let frameCount = AVAudioFrameCount(format.sampleRate * duration)
        guard let buffer = AVAudioPCMBuffer(pcmFormat: format, frameCapacity: frameCount),
              let samples = buffer.floatChannelData?[0] else { return }

        buffer.frameLength = frameCount
        var phase = 0.0

        for frame in 0..<Int(frameCount) {
            let progress = Double(frame) / Double(max(1, Int(frameCount) - 1))
            let frequency = startFrequency + (endFrequency - startFrequency) * progress
            phase += 2 * .pi * frequency / format.sampleRate

            let fadeIn = min(1, progress * 12)
            let envelope = fadeIn * exp(-progress * decay)
            let warble = 1 + 0.08 * sin(2 * .pi * 9 * progress)
            samples[frame] = Float(sin(phase) * envelope * amplitude * warble)
        }

        player.scheduleBuffer(buffer, completionHandler: nil)
        if !player.isPlaying {
            player.play()
        }
    }
}
