import SpriteKit
import UIKit

final class TargetNode: SKNode {
    let profile: TargetProfile
    let targetDiameter: CGFloat
    var movementRadius: CGFloat {
        switch profile.kind {
        case .tadpole, .catString:
            return targetDiameter
        case .worm:
            return targetDiameter * 0.86
        default:
            return targetDiameter * 0.78
        }
    }
    var isReacting = false

    private let bodyContainer = SKNode()
    private var lastHeadingPosition: CGPoint?

    init(profile: TargetProfile, diameter: CGFloat, faceImage: UIImage?) {
        self.profile = profile
        targetDiameter = diameter
        super.init()

        name = "huntTarget"
        zPosition = 10
        addChild(bodyContainer)
        buildBody(for: profile.kind)
        addFace(image: faceImage, for: profile.kind)
        alignBodyForward(for: profile.kind)

        let hitAreaSize: CGSize
        switch profile.kind {
        case .tadpole, .worm, .catString:
            hitAreaSize = CGSize(width: diameter * 1.9, height: diameter * 0.78)
        default:
            hitAreaSize = CGSize(width: diameter * 1.16, height: diameter * 1.16)
        }
        let hitArea = SKShapeNode(ellipseOf: hitAreaSize)
        hitArea.name = "targetHitArea"
        hitArea.fillColor = UIColor.white.withAlphaComponent(0.001)
        hitArea.strokeColor = .clear
        hitArea.zPosition = -2
        addChild(hitArea)
    }

    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    func prepareHeading(toward point: CGPoint) {
        lastHeadingPosition = position
        applyHeading(dx: point.x - position.x, dy: point.y - position.y)
    }

    func updateHeadingFromMovement() {
        guard !isReacting else { return }
        defer { lastHeadingPosition = position }
        guard let previous = lastHeadingPosition else { return }

        let dx = position.x - previous.x
        let dy = position.y - previous.y
        guard hypot(dx, dy) > 0.2 else { return }
        applyHeading(dx: dx, dy: dy)
    }

    private func applyHeading(dx: CGFloat, dy: CGFloat) {
        guard abs(dx) + abs(dy) > 0.001 else { return }
        zRotation = atan2(dy, dx)
    }

    private func buildBody(for kind: TargetKind) {
        switch kind {
        case .mouse: buildMouse()
        case .fish: buildFish()
        case .butterfly: buildButterfly()
        case .beetle: buildBeetle()
        case .yarnBall: buildYarnBall()
        case .feather: buildFeather()
        case .tadpole: buildTadpole()
        case .worm: buildWorm()
        case .catString: buildCatString()
        }
    }

    private func alignBodyForward(for kind: TargetKind) {
        switch kind {
        case .butterfly, .beetle:
            // These bodies are drawn facing up. Rotate their local artwork so
            // SpriteKit's +X path direction becomes the visible head direction.
            bodyContainer.zRotation = -.pi / 2
        case .feather:
            bodyContainer.zRotation = -.pi / 4
        case .mouse, .fish, .yarnBall, .tadpole, .worm, .catString:
            bodyContainer.zRotation = 0
        }
    }

    private func buildMouse() {
        let d = targetDiameter
        addEllipse(size: CGSize(width: d * 0.95, height: d * 0.58), color: .systemGray3)

        let earBack = circle(radius: d * 0.16, color: .systemPink)
        earBack.position = CGPoint(x: d * 0.26, y: d * 0.24)
        bodyContainer.addChild(earBack)

        let earFront = circle(radius: d * 0.13, color: .systemPink)
        earFront.position = CGPoint(x: d * 0.40, y: d * 0.18)
        bodyContainer.addChild(earFront)

        let tailPath = CGMutablePath()
        tailPath.move(to: .zero)
        tailPath.addCurve(
            to: CGPoint(x: -d * 0.30, y: d * 0.34),
            control1: CGPoint(x: -d * 0.12, y: -d * 0.12),
            control2: CGPoint(x: -d * 0.36, y: d * 0.10)
        )
        let tail = SKShapeNode(path: tailPath)
        tail.strokeColor = .systemPink
        tail.lineWidth = max(3, d * 0.045)
        tail.lineCap = .round
        tail.zPosition = -1
        tail.position = CGPoint(x: -d * 0.45, y: 0)
        bodyContainer.addChild(tail)
        animateWag(tail, amplitude: 0.30, halfDuration: 0.16)
    }

    private func buildFish() {
        let d = targetDiameter
        addEllipse(size: CGSize(width: d, height: d * 0.58), color: .systemTeal)

        let tailPath = CGMutablePath()
        tailPath.move(to: .zero)
        tailPath.addLine(to: CGPoint(x: -d * 0.30, y: d * 0.30))
        tailPath.addLine(to: CGPoint(x: -d * 0.30, y: -d * 0.30))
        tailPath.closeSubpath()
        let tail = SKShapeNode(path: tailPath)
        tail.fillColor = .systemBlue
        tail.strokeColor = .white.withAlphaComponent(0.6)
        tail.lineWidth = 2
        tail.zPosition = -1
        tail.position = CGPoint(x: -d * 0.42, y: 0)
        bodyContainer.addChild(tail)
        animateWag(tail, amplitude: 0.24, halfDuration: 0.11)
    }

    private func buildButterfly() {
        let d = targetDiameter
        let leftWing = SKShapeNode(ellipseOf: CGSize(width: d * 0.52, height: d * 0.78))
        leftWing.fillColor = .systemPurple
        leftWing.strokeColor = .systemPink
        leftWing.lineWidth = 3
        leftWing.position.x = -d * 0.25
        leftWing.zRotation = -0.24
        bodyContainer.addChild(leftWing)

        let rightWing = leftWing.copy() as! SKShapeNode
        rightWing.position.x = d * 0.25
        rightWing.zRotation = 0.24
        bodyContainer.addChild(rightWing)

        let body = SKShapeNode(ellipseOf: CGSize(width: d * 0.20, height: d * 0.74))
        body.fillColor = .systemIndigo
        body.strokeColor = .white.withAlphaComponent(0.5)
        body.lineWidth = 2
        bodyContainer.addChild(body)
    }

    private func buildBeetle() {
        let d = targetDiameter
        addEllipse(size: CGSize(width: d * 0.76, height: d), color: .systemRed)

        let centerLine = SKShapeNode(rectOf: CGSize(width: 2, height: d * 0.72))
        centerLine.fillColor = .black.withAlphaComponent(0.55)
        centerLine.strokeColor = .clear
        bodyContainer.addChild(centerLine)

        for x in [CGFloat(-0.20), CGFloat(0.20)] {
            for y in [CGFloat(-0.20), CGFloat(0.06), CGFloat(0.28)] {
                let spot = circle(radius: d * 0.045, color: .black)
                spot.position = CGPoint(x: d * x, y: d * y)
                bodyContainer.addChild(spot)
            }
        }
    }

    private func buildYarnBall() {
        let d = targetDiameter
        let ball = circle(radius: d * 0.47, color: .systemOrange)
        ball.strokeColor = .systemYellow
        ball.lineWidth = 4
        bodyContainer.addChild(ball)

        for rotation in [CGFloat(-0.8), 0, 0.8] {
            let strand = SKShapeNode(ellipseOf: CGSize(width: d * 0.72, height: d * 0.30))
            strand.strokeColor = .white.withAlphaComponent(0.65)
            strand.lineWidth = max(2, d * 0.025)
            strand.fillColor = .clear
            strand.zRotation = rotation
            bodyContainer.addChild(strand)
        }
    }

    private func buildFeather() {
        let d = targetDiameter
        let featherPath = CGMutablePath()
        featherPath.move(to: CGPoint(x: -d * 0.46, y: -d * 0.34))
        featherPath.addCurve(
            to: CGPoint(x: d * 0.44, y: d * 0.34),
            control1: CGPoint(x: -d * 0.18, y: d * 0.52),
            control2: CGPoint(x: d * 0.36, y: d * 0.54)
        )
        featherPath.addCurve(
            to: CGPoint(x: -d * 0.46, y: -d * 0.34),
            control1: CGPoint(x: d * 0.22, y: -d * 0.48),
            control2: CGPoint(x: -d * 0.28, y: -d * 0.52)
        )
        let feather = SKShapeNode(path: featherPath)
        feather.fillColor = .systemMint
        feather.strokeColor = .white
        feather.lineWidth = 3
        feather.zRotation = -0.35
        bodyContainer.addChild(feather)

        let shaftPath = CGMutablePath()
        shaftPath.move(to: CGPoint(x: -d * 0.48, y: -d * 0.37))
        shaftPath.addLine(to: CGPoint(x: d * 0.42, y: d * 0.34))
        let shaft = SKShapeNode(path: shaftPath)
        shaft.strokeColor = .white.withAlphaComponent(0.85)
        shaft.lineWidth = 2
        bodyContainer.addChild(shaft)
    }

    private func buildTadpole() {
        let d = targetDiameter
        let head = SKShapeNode(ellipseOf: CGSize(width: d * 0.62, height: d * 0.54))
        head.fillColor = .systemGreen
        head.strokeColor = .white.withAlphaComponent(0.75)
        head.lineWidth = 3
        head.position.x = d * 0.22
        bodyContainer.addChild(head)

        let tailPath = CGMutablePath()
        tailPath.move(to: .zero)
        tailPath.addCurve(
            to: CGPoint(x: -d * 0.82, y: 0),
            control1: CGPoint(x: -d * 0.22, y: d * 0.34),
            control2: CGPoint(x: -d * 0.58, y: -d * 0.34)
        )
        let tail = SKShapeNode(path: tailPath)
        tail.strokeColor = .systemMint
        tail.lineWidth = max(5, d * 0.10)
        tail.lineCap = .round
        tail.position = CGPoint(x: -d * 0.04, y: 0)
        tail.zPosition = -1
        bodyContainer.addChild(tail)
        animateWag(tail, amplitude: 0.42, halfDuration: 0.12)
    }

    private func buildWorm() {
        let d = targetDiameter
        let segmentCount = 8

        for index in 0..<segmentCount {
            let progress = CGFloat(index) / CGFloat(segmentCount - 1)
            let radius = d * (0.18 - progress * 0.065)
            let segment = circle(radius: radius, color: index == 0 ? .systemYellow : .systemPink)
            segment.position = CGPoint(
                x: d * 0.30 - CGFloat(index) * d * 0.14,
                y: sin(CGFloat(index) * 0.9) * d * 0.10
            )
            segment.zPosition = CGFloat(segmentCount - index)
            bodyContainer.addChild(segment)

            let delay = SKAction.wait(forDuration: Double(index) * 0.025)
            let wave = SKAction.sequence([
                .moveBy(x: 0, y: d * 0.13, duration: 0.13),
                .moveBy(x: 0, y: -d * 0.26, duration: 0.26),
                .moveBy(x: 0, y: d * 0.13, duration: 0.13)
            ])
            segment.run(.sequence([delay, .repeatForever(wave)]))
        }
    }

    private func buildCatString() {
        let d = targetDiameter
        let knot = circle(radius: d * 0.25, color: .systemOrange)
        knot.position = CGPoint(x: d * 0.32, y: 0)
        knot.lineWidth = 3
        bodyContainer.addChild(knot)

        let stringPath = CGMutablePath()
        stringPath.move(to: .zero)
        stringPath.addCurve(
            to: CGPoint(x: -d * 0.88, y: -d * 0.04),
            control1: CGPoint(x: -d * 0.22, y: d * 0.42),
            control2: CGPoint(x: -d * 0.58, y: -d * 0.42)
        )
        let string = SKShapeNode(path: stringPath)
        string.strokeColor = .systemYellow
        string.lineWidth = max(4, d * 0.065)
        string.lineCap = .round
        string.position = CGPoint(x: d * 0.10, y: 0)
        string.zPosition = -1
        bodyContainer.addChild(string)
        animateWag(string, amplitude: 0.48, halfDuration: 0.10)
    }

    private func animateWag(_ node: SKNode, amplitude: CGFloat, halfDuration: TimeInterval) {
        let wag = SKAction.sequence([
            .rotate(toAngle: amplitude, duration: halfDuration, shortestUnitArc: true),
            .rotate(toAngle: -amplitude, duration: halfDuration * 2, shortestUnitArc: true),
            .rotate(toAngle: 0, duration: halfDuration, shortestUnitArc: true)
        ])
        node.run(.repeatForever(wag))
    }

    private func addEllipse(size: CGSize, color: UIColor) {
        let shape = SKShapeNode(ellipseOf: size)
        shape.fillColor = color
        shape.strokeColor = .white.withAlphaComponent(0.7)
        shape.lineWidth = 3
        bodyContainer.addChild(shape)
    }

    private func circle(radius: CGFloat, color: UIColor) -> SKShapeNode {
        let shape = SKShapeNode(circleOfRadius: radius)
        shape.fillColor = color
        shape.strokeColor = .white.withAlphaComponent(0.55)
        shape.lineWidth = 2
        return shape
    }

    private func addFace(image: UIImage?, for kind: TargetKind) {
        let d = targetDiameter
        let diameter: CGFloat
        let position: CGPoint

        switch kind {
        case .mouse, .fish:
            diameter = d * 0.34
            position = CGPoint(x: d * 0.24, y: d * 0.02)
        case .butterfly, .beetle:
            diameter = d * 0.30
            position = CGPoint(x: 0, y: d * 0.27)
        case .yarnBall:
            diameter = d * 0.38
            position = .zero
        case .feather:
            diameter = d * 0.30
            position = CGPoint(x: d * 0.18, y: d * 0.17)
        case .tadpole:
            diameter = d * 0.34
            position = CGPoint(x: d * 0.28, y: d * 0.02)
        case .worm:
            diameter = d * 0.28
            position = CGPoint(x: d * 0.30, y: d * 0.02)
        case .catString:
            diameter = d * 0.34
            position = CGPoint(x: d * 0.32, y: 0)
        }

        let face = image.map { photoFace($0, diameter: diameter) } ?? defaultFace(diameter: diameter)
        face.position = position
        face.zPosition = 20
        bodyContainer.addChild(face)
    }

    private func photoFace(_ image: UIImage, diameter: CGFloat) -> SKNode {
        let container = SKNode()
        let crop = SKCropNode()
        let mask = SKShapeNode(circleOfRadius: diameter / 2)
        mask.fillColor = .white
        mask.strokeColor = .clear
        crop.maskNode = mask

        let texture = SKTexture(image: image)
        texture.filteringMode = .linear
        let sprite = SKSpriteNode(texture: texture, size: CGSize(width: diameter, height: diameter))
        crop.addChild(sprite)
        container.addChild(crop)

        let border = SKShapeNode(circleOfRadius: diameter / 2)
        border.fillColor = .clear
        border.strokeColor = .white
        border.lineWidth = max(2, diameter * 0.06)
        container.addChild(border)
        return container
    }

    private func defaultFace(diameter: CGFloat) -> SKNode {
        let container = SKNode()
        let face = circle(radius: diameter / 2, color: .systemYellow)
        container.addChild(face)

        for direction in [CGFloat(-1), CGFloat(1)] {
            let eye = SKShapeNode(circleOfRadius: diameter * 0.07)
            eye.fillColor = .black
            eye.strokeColor = .clear
            eye.position = CGPoint(x: diameter * 0.16 * direction, y: diameter * 0.08)
            container.addChild(eye)
        }

        let mouthPath = CGMutablePath()
        mouthPath.move(to: CGPoint(x: -diameter * 0.12, y: -diameter * 0.10))
        mouthPath.addQuadCurve(
            to: CGPoint(x: diameter * 0.12, y: -diameter * 0.10),
            control: CGPoint(x: 0, y: -diameter * 0.23)
        )
        let mouth = SKShapeNode(path: mouthPath)
        mouth.strokeColor = .black
        mouth.lineWidth = max(1.5, diameter * 0.045)
        mouth.lineCap = .round
        container.addChild(mouth)
        return container
    }
}
