import Foundation

enum TargetKind: String, Codable, CaseIterable, Identifiable {
    case mouse
    case fish
    case butterfly
    case beetle
    case yarnBall
    case feather
    case tadpole
    case worm
    case catString

    var id: String { rawValue }

    var displayName: String {
        switch self {
        case .mouse: return "小老鼠"
        case .fish: return "小鱼"
        case .butterfly: return "蝴蝶"
        case .beetle: return "甲虫"
        case .yarnBall: return "毛线球"
        case .feather: return "羽毛"
        case .tadpole: return "小蝌蚪"
        case .worm: return "蠕动虫"
        case .catString: return "逗猫绳"
        }
    }

    var emoji: String {
        switch self {
        case .mouse: return "🐭"
        case .fish: return "🐟"
        case .butterfly: return "🦋"
        case .beetle: return "🪲"
        case .yarnBall: return "🧶"
        case .feather: return "🪶"
        case .tadpole: return "◉〰"
        case .worm: return "〰️"
        case .catString: return "➰"
        }
    }
}

enum GameBackgroundStyle: String, Codable, CaseIterable, Identifiable {
    case midnight
    case pureBlack
    case grass
    case water
    case sand
    case violet
    case custom

    var id: String { rawValue }

    var displayName: String {
        switch self {
        case .midnight: return "深夜蓝"
        case .pureBlack: return "纯黑"
        case .grass: return "草地绿"
        case .water: return "池水蓝"
        case .sand: return "暖沙色"
        case .violet: return "紫罗兰"
        case .custom: return "自定义照片"
        }
    }

    var symbolName: String {
        switch self {
        case .midnight: return "moon.stars.fill"
        case .pureBlack: return "circle.fill"
        case .grass: return "leaf.fill"
        case .water: return "drop.fill"
        case .sand: return "sun.max.fill"
        case .violet: return "sparkles"
        case .custom: return "photo.fill"
        }
    }
}

struct TargetProfile: Codable, Equatable, Identifiable {
    static let sizeRange: ClosedRange<Double> = 0.08...0.24
    static let speedRange: ClosedRange<Double> = 0.20...2.40

    let kind: TargetKind
    var isEnabled: Bool
    var normalizedSize: Double
    var normalizedSpeed: Double
    var faceImageFilename: String?

    var id: TargetKind { kind }

    static func defaultProfile(for kind: TargetKind) -> TargetProfile {
        let defaultSpeed: Double
        switch kind {
        case .butterfly, .tadpole, .catString:
            defaultSpeed = 1.0
        case .worm:
            defaultSpeed = 0.8
        default:
            defaultSpeed = 0.75
        }

        return TargetProfile(
            kind: kind,
            isEnabled: [.mouse, .fish, .butterfly, .tadpole].contains(kind),
            normalizedSize: 0.14,
            normalizedSpeed: defaultSpeed,
            faceImageFilename: nil
        )
    }

    mutating func normalize() {
        normalizedSize = min(max(normalizedSize, Self.sizeRange.lowerBound), Self.sizeRange.upperBound)
        normalizedSpeed = min(max(normalizedSpeed, Self.speedRange.lowerBound), Self.speedRange.upperBound)
    }
}

struct GameSettings: Codable, Equatable {
    var profiles: [TargetProfile]
    var activeTargetCount: Int
    var movementSoundEnabled: Bool
    var hitSoundEnabled: Bool
    var movementSoundVolume: Double
    var customMovementSoundFilename: String?
    var hasShownGuidedAccessTip: Bool
    var backgroundStyle: GameBackgroundStyle
    var customBackgroundFilename: String?

    var soundEnabled: Bool {
        get { movementSoundEnabled || hitSoundEnabled }
        set {
            movementSoundEnabled = newValue
            hitSoundEnabled = newValue
        }
    }

    init(
        profiles: [TargetProfile],
        activeTargetCount: Int,
        soundEnabled: Bool,
        hasShownGuidedAccessTip: Bool,
        backgroundStyle: GameBackgroundStyle = .midnight,
        customBackgroundFilename: String? = nil,
        movementSoundEnabled: Bool? = nil,
        hitSoundEnabled: Bool? = nil,
        movementSoundVolume: Double = 0.75,
        customMovementSoundFilename: String? = nil
    ) {
        self.profiles = profiles
        self.activeTargetCount = activeTargetCount
        self.movementSoundEnabled = movementSoundEnabled ?? soundEnabled
        self.hitSoundEnabled = hitSoundEnabled ?? soundEnabled
        self.movementSoundVolume = movementSoundVolume
        self.customMovementSoundFilename = customMovementSoundFilename
        self.hasShownGuidedAccessTip = hasShownGuidedAccessTip
        self.backgroundStyle = backgroundStyle
        self.customBackgroundFilename = customBackgroundFilename
    }

    static var defaults: GameSettings {
        GameSettings(
            profiles: TargetKind.allCases.map(TargetProfile.defaultProfile),
            activeTargetCount: 1,
            soundEnabled: true,
            hasShownGuidedAccessTip: false,
            backgroundStyle: .midnight,
            movementSoundVolume: 0.75
        )
    }

    var enabledProfiles: [TargetProfile] {
        profiles.filter(\.isEnabled)
    }

    mutating func normalize() {
        activeTargetCount = min(max(activeTargetCount, 1), 8)
        movementSoundVolume = min(max(movementSoundVolume, 0), 1)

        var byKind: [TargetKind: TargetProfile] = [:]
        for profile in profiles {
            byKind[profile.kind] = profile
        }
        profiles = TargetKind.allCases.map { kind in
            var profile = byKind.removeValue(forKey: kind) ?? .defaultProfile(for: kind)
            profile.normalize()
            return profile
        }

        if !profiles.contains(where: \.isEnabled), !profiles.isEmpty {
            profiles[0].isEnabled = true
        }
    }

    func profile(for kind: TargetKind) -> TargetProfile {
        profiles.first(where: { $0.kind == kind }) ?? .defaultProfile(for: kind)
    }

    private enum CodingKeys: String, CodingKey {
        case profiles
        case activeTargetCount
        case soundEnabled
        case movementSoundEnabled
        case hitSoundEnabled
        case movementSoundVolume
        case customMovementSoundFilename
        case hasShownGuidedAccessTip
        case backgroundStyle
        case customBackgroundFilename
    }

    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        profiles = try container.decode([TargetProfile].self, forKey: .profiles)
        activeTargetCount = try container.decode(Int.self, forKey: .activeTargetCount)
        let legacySoundEnabled = try container.decodeIfPresent(Bool.self, forKey: .soundEnabled) ?? true
        movementSoundEnabled = try container.decodeIfPresent(Bool.self, forKey: .movementSoundEnabled) ?? legacySoundEnabled
        hitSoundEnabled = try container.decodeIfPresent(Bool.self, forKey: .hitSoundEnabled) ?? legacySoundEnabled
        movementSoundVolume = try container.decodeIfPresent(Double.self, forKey: .movementSoundVolume) ?? 0.75
        customMovementSoundFilename = try container.decodeIfPresent(String.self, forKey: .customMovementSoundFilename)
        hasShownGuidedAccessTip = try container.decodeIfPresent(Bool.self, forKey: .hasShownGuidedAccessTip) ?? false
        backgroundStyle = try container.decodeIfPresent(GameBackgroundStyle.self, forKey: .backgroundStyle) ?? .midnight
        customBackgroundFilename = try container.decodeIfPresent(String.self, forKey: .customBackgroundFilename)
    }

    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encode(profiles, forKey: .profiles)
        try container.encode(activeTargetCount, forKey: .activeTargetCount)
        try container.encode(soundEnabled, forKey: .soundEnabled)
        try container.encode(movementSoundEnabled, forKey: .movementSoundEnabled)
        try container.encode(hitSoundEnabled, forKey: .hitSoundEnabled)
        try container.encode(movementSoundVolume, forKey: .movementSoundVolume)
        try container.encodeIfPresent(customMovementSoundFilename, forKey: .customMovementSoundFilename)
        try container.encode(hasShownGuidedAccessTip, forKey: .hasShownGuidedAccessTip)
        try container.encode(backgroundStyle, forKey: .backgroundStyle)
        try container.encodeIfPresent(customBackgroundFilename, forKey: .customBackgroundFilename)
    }
}

enum TargetSelector {
    static func choose(from profiles: [TargetProfile], count: Int) -> [TargetProfile] {
        guard !profiles.isEmpty else { return [] }
        return (0..<max(0, count)).compactMap { _ in profiles.randomElement() }
    }
}
