import Foundation
import SpriteKit
import XCTest
@testable import KakaHunt

final class GameSettingsTests: XCTestCase {
    func testDefaultsContainEveryTargetKind() {
        let settings = GameSettings.defaults

        XCTAssertEqual(settings.profiles.map(\.kind), TargetKind.allCases)
        XCTAssertFalse(settings.enabledProfiles.isEmpty)
        XCTAssertEqual(settings.activeTargetCount, 1)
        XCTAssertTrue(settings.movementSoundEnabled)
        XCTAssertTrue(settings.hitSoundEnabled)
        XCTAssertEqual(settings.movementSoundVolume, 0.75)
    }

    func testNormalizeClampsValuesAndRestoresEnabledTarget() {
        var settings = GameSettings(
            profiles: [
                TargetProfile(
                    kind: .fish,
                    isEnabled: false,
                    normalizedSize: 2,
                    normalizedSpeed: -1,
                    faceImageFilename: nil
                )
            ],
            activeTargetCount: 20,
            soundEnabled: false,
            hasShownGuidedAccessTip: true,
            movementSoundVolume: 5
        )

        settings.normalize()

        XCTAssertEqual(settings.profiles.map(\.kind), TargetKind.allCases)
        XCTAssertEqual(settings.activeTargetCount, 8)
        XCTAssertEqual(settings.movementSoundVolume, 1)
        XCTAssertTrue(settings.profiles[0].isEnabled)
        XCTAssertEqual(settings.profile(for: .fish).normalizedSize, TargetProfile.sizeRange.upperBound)
        XCTAssertEqual(settings.profile(for: .fish).normalizedSpeed, TargetProfile.speedRange.lowerBound)
    }

    func testTargetSelectorUsesOnlyEnabledPoolAndAllowsRequestedCount() {
        let pool = [
            TargetProfile.defaultProfile(for: .mouse),
            TargetProfile.defaultProfile(for: .butterfly)
        ]

        let result = TargetSelector.choose(from: pool, count: 30)

        XCTAssertEqual(result.count, 30)
        XCTAssertTrue(result.allSatisfy { [.mouse, .butterfly].contains($0.kind) })
    }

    func testTargetSelectorHandlesEmptyPool() {
        XCTAssertTrue(TargetSelector.choose(from: [], count: 3).isEmpty)
    }

    func testTargetHeadingUsesActualMovementVector() {
        let node = TargetNode(
            profile: .defaultProfile(for: .mouse),
            diameter: 100,
            faceImage: nil
        )
        node.position = .zero
        node.prepareHeading(toward: CGPoint(x: -10, y: 0))
        XCTAssertEqual(abs(node.zRotation), .pi, accuracy: 0.001)

        node.position = CGPoint(x: 0, y: 10)
        node.updateHeadingFromMovement()
        XCTAssertEqual(node.zRotation, .pi / 2, accuracy: 0.001)
    }

    func testNormalizeToleratesDuplicateProfiles() {
        var first = TargetProfile.defaultProfile(for: .mouse)
        first.normalizedSize = 0.10
        var replacement = first
        replacement.normalizedSize = 0.20
        var settings = GameSettings(
            profiles: [first, replacement],
            activeTargetCount: 1,
            soundEnabled: true,
            hasShownGuidedAccessTip: false
        )

        settings.normalize()

        XCTAssertEqual(settings.profiles.count, TargetKind.allCases.count)
        XCTAssertEqual(settings.profile(for: .mouse).normalizedSize, 0.20)
    }

    @MainActor
    func testSettingsStorePersistsChanges() throws {
        let suiteName = "KakaHuntTests-\(UUID().uuidString)"
        let defaults = try XCTUnwrap(UserDefaults(suiteName: suiteName))
        defer { defaults.removePersistentDomain(forName: suiteName) }

        let firstStore = SettingsStore(defaults: defaults)
        firstStore.updateProfile(.mouse) {
            $0.normalizedSize = 0.2
            $0.normalizedSpeed = 0.4
        }
        firstStore.update {
            $0.activeTargetCount = 7
            $0.backgroundStyle = .custom
            $0.customBackgroundFilename = "background.jpg"
            $0.movementSoundEnabled = false
            $0.hitSoundEnabled = true
            $0.movementSoundVolume = 0.42
            $0.customMovementSoundFilename = "movement.m4a"
        }

        let restoredStore = SettingsStore(defaults: defaults)
        XCTAssertEqual(restoredStore.settings.profile(for: .mouse).normalizedSize, 0.2)
        XCTAssertEqual(restoredStore.settings.profile(for: .mouse).normalizedSpeed, 0.4)
        XCTAssertEqual(restoredStore.settings.activeTargetCount, 7)
        XCTAssertEqual(restoredStore.settings.backgroundStyle, .custom)
        XCTAssertEqual(restoredStore.settings.customBackgroundFilename, "background.jpg")
        XCTAssertFalse(restoredStore.settings.movementSoundEnabled)
        XCTAssertTrue(restoredStore.settings.hitSoundEnabled)
        XCTAssertEqual(restoredStore.settings.movementSoundVolume, 0.42)
        XCTAssertEqual(restoredStore.settings.customMovementSoundFilename, "movement.m4a")
    }

    @MainActor
    func testSettingsStoreFallsBackFromCorruptedData() throws {
        let suiteName = "KakaHuntTests-\(UUID().uuidString)"
        let defaults = try XCTUnwrap(UserDefaults(suiteName: suiteName))
        defer { defaults.removePersistentDomain(forName: suiteName) }
        defaults.set(Data("not-json".utf8), forKey: "kaka-hunt.settings.v3")

        let store = SettingsStore(defaults: defaults)

        XCTAssertEqual(store.settings, .defaults)
    }

    @MainActor
    func testVersionOneSpeedIsMigratedToFasterRange() throws {
        let suiteName = "KakaHuntTests-\(UUID().uuidString)"
        let defaults = try XCTUnwrap(UserDefaults(suiteName: suiteName))
        defer { defaults.removePersistentDomain(forName: suiteName) }

        var legacySettings = GameSettings.defaults
        if let mouseIndex = legacySettings.profiles.firstIndex(where: { $0.kind == .mouse }) {
            legacySettings.profiles[mouseIndex].normalizedSpeed = 0.22
        }
        defaults.set(try JSONEncoder().encode(legacySettings), forKey: "kaka-hunt.settings.v1")

        let store = SettingsStore(defaults: defaults)

        XCTAssertEqual(store.settings.profile(for: .mouse).normalizedSpeed, 0.748, accuracy: 0.001)
        XCTAssertNotNil(defaults.data(forKey: "kaka-hunt.settings.v3"))
    }

    @MainActor
    func testLegacyCombinedSoundSettingMigratesToBothSwitches() throws {
        struct LegacySettings: Encodable {
            let profiles: [TargetProfile]
            let activeTargetCount: Int
            let soundEnabled: Bool
            let hasShownGuidedAccessTip: Bool
            let backgroundStyle: GameBackgroundStyle
        }

        let suiteName = "KakaHuntTests-\(UUID().uuidString)"
        let defaults = try XCTUnwrap(UserDefaults(suiteName: suiteName))
        defer { defaults.removePersistentDomain(forName: suiteName) }
        let legacy = LegacySettings(
            profiles: GameSettings.defaults.profiles,
            activeTargetCount: 2,
            soundEnabled: false,
            hasShownGuidedAccessTip: true,
            backgroundStyle: .water
        )
        defaults.set(try JSONEncoder().encode(legacy), forKey: "kaka-hunt.settings.v3")

        let store = SettingsStore(defaults: defaults)

        XCTAssertFalse(store.settings.movementSoundEnabled)
        XCTAssertFalse(store.settings.hitSoundEnabled)
        XCTAssertEqual(store.settings.movementSoundVolume, 0.75)
    }
}
