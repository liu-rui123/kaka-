import SpriteKit
import SwiftUI
import UIKit

struct GameView: View {
    let onExit: () -> Void

    @Environment(\.scenePhase) private var scenePhase
    @State private var scene: HuntScene

    init(settings: GameSettings, onExit: @escaping () -> Void) {
        self.onExit = onExit

        var faces: [TargetKind: UIImage] = [:]
        for profile in settings.profiles {
            if let image = FaceImageStore.image(filename: profile.faceImageFilename) {
                faces[profile.kind] = image
            }
        }
        _scene = State(initialValue: HuntScene(settings: settings, faceImages: faces))
    }

    var body: some View {
        ZStack(alignment: .topTrailing) {
            SpriteView(scene: scene, options: [.ignoresSiblingOrder])
                .ignoresSafeArea()

            OwnerExitControl {
                UIApplication.shared.isIdleTimerDisabled = false
                onExit()
            }
            .padding(.top, 12)
            .padding(.trailing, 12)
        }
        .background(Color.black)
        .persistentSystemOverlays(.hidden)
        .defersSystemGestures(on: .all)
        .statusBarHidden(true)
        .onAppear {
            UIApplication.shared.isIdleTimerDisabled = true
            scene.isPaused = false
        }
        .onDisappear {
            UIApplication.shared.isIdleTimerDisabled = false
        }
        .onChange(of: scenePhase) { phase in
            scene.isPaused = phase != .active
        }
    }
}

private struct OwnerExitControl: View {
    let onExit: () -> Void

    @State private var progress: CGFloat = 0

    var body: some View {
        ZStack {
            Circle()
                .fill(.black.opacity(0.48))

            Circle()
                .trim(from: 0, to: progress)
                .stroke(.white, style: StrokeStyle(lineWidth: 4, lineCap: .round))
                .rotationEffect(.degrees(-90))

            VStack(spacing: 1) {
                Image(systemName: "lock.open.fill")
                    .font(.system(size: 19, weight: .bold))
                Text("按住退出")
                    .font(.system(size: 9, weight: .semibold))
            }
            .foregroundStyle(.white)
        }
        .frame(width: 68, height: 68)
        .contentShape(Circle())
        .onLongPressGesture(
            minimumDuration: 3,
            maximumDistance: 100,
            pressing: { isPressing in
                if isPressing {
                    progress = 0
                    withAnimation(.linear(duration: 3)) {
                        progress = 1
                    }
                } else {
                    withAnimation(.easeOut(duration: 0.15)) {
                        progress = 0
                    }
                }
            },
            perform: onExit
        )
        .accessibilityLabel("按住三秒退出游戏")
        .accessibilityHint("持续按住，进度环结束后返回设置")
    }
}
