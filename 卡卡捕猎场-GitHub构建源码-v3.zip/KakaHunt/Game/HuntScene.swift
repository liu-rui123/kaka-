import SpriteKit
import UIKit

final class HuntScene: SKScene {
    private let settings: GameSettings
    private let faceImages: [TargetKind: UIImage]
    private let soundPlayer = GameSoundPlayer()
    private var hasSpawnedTargets = false
    private var lastAttractTime: TimeInterval = 0
    private var nextAttractInterval = 2.5

    private enum ScreenEdge: CaseIterable {
        case left
        case right
        case bottom
        case top

        var opposite: ScreenEdge {
            switch self {
            case .left: return .right
            case .right: return .left
            case .bottom: return .top
            case .top: return .bottom
            }
        }
    }

    init(settings: GameSettings, faceImages: [TargetKind: UIImage]) {
        self.settings = settings
        self.faceImages = faceImages
        super.init(size: UIScreen.main.bounds.size)
        scaleMode = .resizeFill
        backgroundColor = Self.color(for: settings.backgroundStyle)
        anchorPoint = .zero
    }

    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    deinit {
        soundPlayer.stop()
    }

    override func didMove(to view: SKView) {
        view.isMultipleTouchEnabled = true
        view.preferredFramesPerSecond = 60
        guard !hasSpawnedTargets else { return }
        hasSpawnedTargets = true

        for profile in TargetSelector.choose(from: settings.enabledProfiles, count: settings.activeTargetCount) {
            spawnTarget(profile: profile)
        }
        nextAttractInterval = randomAttractInterval()
    }

    override func update(_ currentTime: TimeInterval) {
        guard settings.soundEnabled, hasSpawnedTargets else { return }

        if lastAttractTime == 0 {
            lastAttractTime = currentTime
            return
        }

        guard currentTime - lastAttractTime >= nextAttractInterval else { return }
        lastAttractTime = currentTime
        nextAttractInterval = randomAttractInterval()

        let targets = children.compactMap { $0 as? TargetNode }.filter {
            !$0.isReacting && self.frame.insetBy(dx: -$0.movementRadius, dy: -$0.movementRadius).contains($0.position)
        }
        if let target = targets.randomElement() {
            if settings.activeTargetCount == 1 {
                soundPlayer.playMouseRustle()
            } else {
                soundPlayer.playAttract(for: target.profile.kind)
            }
            showAttractPulse(around: target)
        }
    }

    override func didChangeSize(_ oldSize: CGSize) {
        super.didChangeSize(oldSize)
        guard size.width > 0, size.height > 0 else { return }

        enumerateChildNodes(withName: "huntTarget") { [weak self] node, _ in
            guard let self, let target = node as? TargetNode else { return }
            target.position = self.randomEntryPoint(radius: target.movementRadius)
            self.startMovement(for: target)
        }
    }

    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        var handled = Set<ObjectIdentifier>()

        for touch in touches {
            let location = touch.location(in: self)
            guard let target = targetNode(at: location), !target.isReacting else { continue }
            let identifier = ObjectIdentifier(target)
            guard handled.insert(identifier).inserted else { continue }
            reactToHit(target, at: location)
        }
    }

    private func targetNode(at point: CGPoint) -> TargetNode? {
        for node in nodes(at: point).reversed() {
            var candidate: SKNode? = node
            while let current = candidate {
                if let target = current as? TargetNode { return target }
                candidate = current.parent
            }
        }
        return nil
    }

    private func reactToHit(_ target: TargetNode, at location: CGPoint) {
        target.isReacting = true
        target.removeAction(forKey: "movement")
        showHitEffect(at: location, diameter: target.targetDiameter)

        if settings.soundEnabled {
            soundPlayer.playHit()
        }

        let pop = SKAction.group([
            .scale(to: 1.32, duration: 0.10),
            .fadeAlpha(to: 0.18, duration: 0.20),
            .rotate(byAngle: CGFloat.random(in: -0.8...0.8), duration: 0.20)
        ])
        pop.timingMode = .easeOut

        target.run(pop) { [weak self, weak target] in
            guard let self, let target else { return }
            target.removeFromParent()
            guard let nextProfile = self.settings.enabledProfiles.randomElement() else { return }
            self.spawnTarget(profile: nextProfile)
        }
    }

    private func showHitEffect(at point: CGPoint, diameter: CGFloat) {
        let effect = SKNode()
        effect.position = point
        effect.zPosition = 100
        addChild(effect)

        let ring = SKShapeNode(circleOfRadius: max(16, diameter * 0.25))
        ring.strokeColor = .systemYellow
        ring.lineWidth = max(4, diameter * 0.055)
        ring.glowWidth = 5
        ring.fillColor = .clear
        effect.addChild(ring)
        ring.run(.group([
            .scale(to: 2.5, duration: 0.34),
            .fadeOut(withDuration: 0.34)
        ]))

        let sparkCount = 10
        for index in 0..<sparkCount {
            let angle = CGFloat(index) / CGFloat(sparkCount) * 2 * .pi + CGFloat.random(in: -0.15...0.15)
            let spark = SKShapeNode(circleOfRadius: max(2.5, diameter * 0.035))
            spark.fillColor = index.isMultiple(of: 2) ? .systemYellow : .white
            spark.strokeColor = .clear
            effect.addChild(spark)

            let distance = diameter * CGFloat.random(in: 0.48...0.82)
            let destination = CGPoint(x: cos(angle) * distance, y: sin(angle) * distance)
            spark.run(.group([
                .move(to: destination, duration: 0.30),
                .scale(to: 0.1, duration: 0.30),
                .fadeOut(withDuration: 0.30)
            ]))
        }

        effect.run(.sequence([.wait(forDuration: 0.38), .removeFromParent()]))
    }

    private func showAttractPulse(around target: TargetNode) {
        let pulse = SKShapeNode(circleOfRadius: target.targetDiameter * 0.55)
        pulse.position = target.position
        pulse.zPosition = target.zPosition - 1
        pulse.strokeColor = .systemTeal.withAlphaComponent(0.75)
        pulse.lineWidth = 3
        pulse.fillColor = .clear
        addChild(pulse)
        pulse.run(.sequence([
            .group([
                .scale(to: 1.65, duration: 0.45),
                .fadeOut(withDuration: 0.45)
            ]),
            .removeFromParent()
        ]))
    }

    private func spawnTarget(profile: TargetProfile) {
        let shortSide = max(1, min(size.width, size.height))
        let diameter = shortSide * CGFloat(profile.normalizedSize)
        let target = TargetNode(
            profile: profile,
            diameter: diameter,
            faceImage: faceImages[profile.kind]
        )
        target.alpha = 0
        target.setScale(0.7)
        target.position = randomEntryPoint(radius: target.movementRadius)
        addChild(target)

        target.run(.group([
            .fadeIn(withDuration: 0.16),
            .scale(to: 1, duration: 0.16)
        ]))
        startMovement(for: target)
    }

    private func startMovement(for target: TargetNode) {
        target.removeAction(forKey: "movement")
        guard target.parent != nil, !target.isReacting else { return }

        let entryEdge = outsideEdge(for: target.position) ?? ScreenEdge.allCases.randomElement() ?? .left
        let destination = outsidePoint(on: entryEdge.opposite, radius: target.movementRadius)
        let distance = hypot(destination.x - target.position.x, destination.y - target.position.y)
        let pointsPerSecond = max(30, min(size.width, size.height) * CGFloat(target.profile.normalizedSpeed))
        let duration = max(0.35, TimeInterval(distance / pointsPerSecond))

        let path = CGMutablePath()
        path.move(to: target.position)
        let delta = CGVector(
            dx: destination.x - target.position.x,
            dy: destination.y - target.position.y
        )
        let pathLength = max(1, hypot(delta.dx, delta.dy))
        let perpendicular = CGVector(dx: -delta.dy / pathLength, dy: delta.dx / pathLength)
        let bend = min(size.width, size.height) * CGFloat.random(in: -0.18...0.18)
        let control1 = CGPoint(
            x: target.position.x + delta.dx * 0.33 + perpendicular.dx * bend,
            y: target.position.y + delta.dy * 0.33 + perpendicular.dy * bend
        )
        let control2 = CGPoint(
            x: target.position.x + delta.dx * 0.66 + perpendicular.dx * bend,
            y: target.position.y + delta.dy * 0.66 + perpendicular.dy * bend
        )
        path.addCurve(to: destination, control1: control1, control2: control2)

        let follow = SKAction.follow(path, asOffset: false, orientToPath: true, duration: duration)
        follow.timingMode = .easeInEaseOut

        target.run(.sequence([
            follow,
            .run { [weak self, weak target] in
                guard let self, let target else { return }
                target.position = self.randomEntryPoint(radius: target.movementRadius)
                self.startMovement(for: target)
            }
        ]), withKey: "movement")
    }

    private func randomEntryPoint(radius: CGFloat) -> CGPoint {
        outsidePoint(
            on: ScreenEdge.allCases.randomElement() ?? .left,
            radius: radius
        )
    }

    private func outsidePoint(on edge: ScreenEdge, radius: CGFloat) -> CGPoint {
        let outsideMargin = radius + 24
        let insideMargin = min(radius + 18, min(size.width, size.height) * 0.35)
        let horizontalRange = insideMargin...max(insideMargin, size.width - insideMargin)
        let verticalRange = insideMargin...max(insideMargin, size.height - insideMargin)

        switch edge {
        case .left:
            return CGPoint(x: -outsideMargin, y: CGFloat.random(in: verticalRange))
        case .right:
            return CGPoint(x: size.width + outsideMargin, y: CGFloat.random(in: verticalRange))
        case .bottom:
            return CGPoint(x: CGFloat.random(in: horizontalRange), y: -outsideMargin)
        case .top:
            return CGPoint(x: CGFloat.random(in: horizontalRange), y: size.height + outsideMargin)
        }
    }

    private func outsideEdge(for point: CGPoint) -> ScreenEdge? {
        if point.x < 0 { return .left }
        if point.x > size.width { return .right }
        if point.y < 0 { return .bottom }
        if point.y > size.height { return .top }
        return nil
    }

    private func randomAttractInterval() -> Double {
        settings.activeTargetCount == 1
            ? Double.random(in: 1.4...2.8)
            : Double.random(in: 2.2...4.2)
    }

    private static func color(for style: GameBackgroundStyle) -> UIColor {
        switch style {
        case .midnight:
            return UIColor(red: 0.025, green: 0.045, blue: 0.075, alpha: 1)
        case .pureBlack:
            return .black
        case .grass:
            return UIColor(red: 0.08, green: 0.24, blue: 0.12, alpha: 1)
        case .water:
            return UIColor(red: 0.04, green: 0.22, blue: 0.34, alpha: 1)
        case .sand:
            return UIColor(red: 0.46, green: 0.32, blue: 0.16, alpha: 1)
        case .violet:
            return UIColor(red: 0.20, green: 0.08, blue: 0.30, alpha: 1)
        }
    }
}
