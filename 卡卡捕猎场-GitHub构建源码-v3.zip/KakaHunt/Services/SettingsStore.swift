import Foundation

@MainActor
final class SettingsStore: ObservableObject {
    @Published private(set) var settings: GameSettings

    private let defaults: UserDefaults
    private let storageKey = "kaka-hunt.settings.v3"
    private let versionTwoStorageKey = "kaka-hunt.settings.v2"
    private let versionOneStorageKey = "kaka-hunt.settings.v1"

    init(defaults: UserDefaults = .standard) {
        self.defaults = defaults

        let currentData = defaults.data(forKey: storageKey)
        let versionTwoData = defaults.data(forKey: versionTwoStorageKey)
        let versionOneData = defaults.data(forKey: versionOneStorageKey)
        let sourceData: Data?
        let speedMultiplier: Double

        if let currentData {
            sourceData = currentData
            speedMultiplier = 1
        } else if let versionTwoData {
            sourceData = versionTwoData
            speedMultiplier = 1.4
        } else {
            sourceData = versionOneData
            speedMultiplier = 3.4
        }

        if let data = sourceData,
           var decoded = try? JSONDecoder().decode(GameSettings.self, from: data) {
            if speedMultiplier != 1 {
                for index in decoded.profiles.indices {
                    decoded.profiles[index].normalizedSpeed *= speedMultiplier
                }
            }
            decoded.normalize()
            settings = decoded
            if currentData == nil, let migrated = try? JSONEncoder().encode(decoded) {
                defaults.set(migrated, forKey: storageKey)
            }
        } else {
            settings = .defaults
        }
    }

    func update(_ mutation: (inout GameSettings) -> Void) {
        var next = settings
        mutation(&next)
        next.normalize()
        settings = next
        persist()
    }

    func updateProfile(_ kind: TargetKind, mutation: (inout TargetProfile) -> Void) {
        update { settings in
            guard let index = settings.profiles.firstIndex(where: { $0.kind == kind }) else { return }
            mutation(&settings.profiles[index])
        }
    }

    func markGuidedAccessTipShown() {
        update { $0.hasShownGuidedAccessTip = true }
    }

    private func persist() {
        guard let data = try? JSONEncoder().encode(settings) else { return }
        defaults.set(data, forKey: storageKey)
    }
}
